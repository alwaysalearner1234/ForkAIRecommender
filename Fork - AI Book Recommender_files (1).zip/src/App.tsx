import  { useState } from "react";
import Header from "./components/Header";
import GenreSelector from "./components/GenreSelector";
import BookList from "./components/BookList";
import { books, genres } from "./data/books";

export default function App() {
  const [selectedGenre, setSelectedGenre] = useState("All");
  
  const filteredBooks = selectedGenre === "All" 
    ? books 
    : books.filter(book => book.genre === selectedGenre);

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1 container mx-auto px-4 py-8">
        <div className="relative mb-8">
          <img 
            src="https://images.unsplash.com/photo-1507738978512-35798112892c?ixlib=rb-4.1.0&fit=fillmax&h=800&w=1200" 
            alt="Books on shelves in a library" 
            className="w-full h-64 object-cover rounded-lg"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/50 to-transparent rounded-lg flex items-center">
            <div className="text-white ml-8 max-w-md">
              <h2 className="text-2xl md:text-3xl font-bold mb-2">
                Find Your Next Great Read
              </h2>
              <p className="text-sm md:text-base">
                Our AI analyzes your preferences to recommend books you'll love
              </p>
            </div>
          </div>
        </div>
        
        <GenreSelector 
          genres={genres} 
          selectedGenre={selectedGenre} 
          onGenreChange={setSelectedGenre} 
        />
        
        <BookList books={filteredBooks} />
      </main>
      
      <footer className="bg-gray-800 text-white py-6">
        <div className="container mx-auto px-4 text-center">
          <p>© 2023 AI Book Recommender. All rights reserved.</p>
          <p className="text-gray-400 text-sm mt-2">
            Powered by advanced AI recommendation algorithms
          </p>
        </div>
      </footer>
    </div>
  );
}
  