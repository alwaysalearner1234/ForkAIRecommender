export  interface Book {
  id: number;
  title: string;
  author: string;
  genre: string;
  description: string;
  coverUrl: string;
  rating: number;
  year: number;
}

export const books: Book[] = [
  {
    id: 1,
    title: "The Midnight Library",
    author: "Matt Haig",
    genre: "Fiction",
    description: "Between life and death there is a library, and within that library, the shelves go on forever. Every book provides a chance to try another life you could have lived.",
    coverUrl: "https://images.unsplash.com/photo-1544947950-fa07a98d237f?ixlib=rb-4.1.0&auto=format&fit=crop&w=300&q=80",
    rating: 4.2,
    year: 2020
  },
  {
    id: 2,
    title: "Sapiens",
    author: "Yuval Noah Harari",
    genre: "Non-fiction",
    description: "A brief history of humankind, exploring how humans evolved from insignificant animals to become the dominant force on the planet.",
    coverUrl: "https://images.unsplash.com/photo-1589998059171-988d887df646?ixlib=rb-4.1.0&auto=format&fit=crop&w=300&q=80",
    rating: 4.5,
    year: 2011
  },
  {
    id: 3,
    title: "Dune",
    author: "Frank Herbert",
    genre: "Science Fiction",
    description: "Set on the desert planet Arrakis, Dune is the story of the boy Paul Atreides, heir to a noble family tasked with ruling an inhospitable world.",
    coverUrl: "https://images.unsplash.com/photo-1531072901881-d644216d4bf9?ixlib=rb-4.1.0&auto=format&fit=crop&w=300&q=80",
    rating: 4.7,
    year: 1965
  },
  {
    id: 4,
    title: "The Silent Patient",
    author: "Alex Michaelides",
    genre: "Mystery",
    description: "A psychological thriller about a woman's act of violence against her husband, and the therapist obsessed with uncovering her motive.",
    coverUrl: "https://images.unsplash.com/photo-1587876931567-564ce588bfbd?ixlib=rb-4.1.0&auto=format&fit=crop&w=300&q=80",
    rating: 4.1,
    year: 2019
  },
  {
    id: 5,
    title: "Where the Crawdads Sing",
    author: "Delia Owens",
    genre: "Fiction",
    description: "A murder mystery, a coming-of-age narrative, and a celebration of nature—all in one novel.",
    coverUrl: "https://images.unsplash.com/photo-1541963463532-d68292c34b19?ixlib=rb-4.1.0&auto=format&fit=crop&w=300&q=80",
    rating: 4.8,
    year: 2018
  },
  {
    id: 6,
    title: "Educated",
    author: "Tara Westover",
    genre: "Non-fiction",
    description: "A memoir about a young girl who, kept out of school, leaves her survivalist family and goes on to earn a PhD from Cambridge University.",
    coverUrl: "https://images.unsplash.com/photo-1543002588-bfa74002ed7e?ixlib=rb-4.1.0&auto=format&fit=crop&w=300&q=80",
    rating: 4.4,
    year: 2018
  },
  {
    id: 7,
    title: "The Hobbit",
    author: "J.R.R. Tolkien",
    genre: "Fantasy",
    description: "The precursor to The Lord of the Rings, this children's fantasy novel follows the adventures of hobbit Bilbo Baggins.",
    coverUrl: "https://images.unsplash.com/photo-1518744386442-2d48ac47a7eb?ixlib=rb-4.1.0&auto=format&fit=crop&w=300&q=80",
    rating: 4.6,
    year: 1937
  },
  {
    id: 8,
    title: "Gone Girl",
    author: "Gillian Flynn",
    genre: "Mystery",
    description: "A thriller novel about the disappearance of a woman on her fifth wedding anniversary.",
    coverUrl: "https://images.unsplash.com/photo-1629992101753-56d196c8aabb?ixlib=rb-4.1.0&auto=format&fit=crop&w=300&q=80",
    rating: 4.2,
    year: 2012
  },
  {
    id: 9,
    title: "The Alchemist",
    author: "Paulo Coelho",
    genre: "Fantasy",
    description: "A philosophical novel about a young Andalusian shepherd who dreams of finding a worldly treasure.",
    coverUrl: "https://images.unsplash.com/photo-1633477189729-9290b3261d0a?ixlib=rb-4.1.0&auto=format&fit=crop&w=300&q=80",
    rating: 4.3,
    year: 1988
  },
  {
    id: 10,
    title: "Atomic Habits",
    author: "James Clear",
    genre: "Self-help",
    description: "A practical guide to breaking bad habits and building good ones.",
    coverUrl: "https://images.unsplash.com/photo-1553729459-efe14ef6055d?ixlib=rb-4.1.0&auto=format&fit=crop&w=300&q=80",
    rating: 4.4,
    year: 2018
  },
  {
    id: 11,
    title: "1984",
    author: "George Orwell",
    genre: "Science Fiction",
    description: "A dystopian novel set in a totalitarian society ruled by the Party, which has total control over every aspect of people's lives.",
    coverUrl: "https://images.unsplash.com/photo-1598618443855-232ee0f819f6?ixlib=rb-4.1.0&auto=format&fit=crop&w=300&q=80",
    rating: 4.5,
    year: 1949
  },
  {
    id: 12,
    title: "The Great Gatsby",
    author: "F. Scott Fitzgerald",
    genre: "Fiction",
    description: "A novel about the mysteriously wealthy Jay Gatsby and his love for the beautiful Daisy Buchanan.",
    coverUrl: "https://images.unsplash.com/photo-1603162525937-96230da43f9e?ixlib=rb-4.1.0&auto=format&fit=crop&w=300&q=80",
    rating: 4.2,
    year: 1925
  },
  {
    id: 13,
    title: "Becoming",
    author: "Michelle Obama",
    genre: "Non-fiction",
    description: "A memoir by the former First Lady of the United States that chronicles the experiences that have shaped her life.",
    coverUrl: "https://images.unsplash.com/photo-1594312915251-48db9280c8f1?ixlib=rb-4.1.0&auto=format&fit=crop&w=300&q=80",
    rating: 4.6,
    year: 2018
  },
  {
    id: 14,
    title: "The Hunger Games",
    author: "Suzanne Collins",
    genre: "Young Adult",
    description: "In a dystopian future, teenagers are forced to fight to the death in a televised spectacle.",
    coverUrl: "https://images.unsplash.com/photo-1599689033872-02c51afd2550?ixlib=rb-4.1.0&auto=format&fit=crop&w=300&q=80",
    rating: 4.3,
    year: 2008
  },
  {
    id: 15,
    title: "To Kill a Mockingbird",
    author: "Harper Lee",
    genre: "Fiction",
    description: "A coming-of-age story about racial injustice and moral growth in the American South during the 1930s.",
    coverUrl: "https://images.unsplash.com/photo-1576872381149-7847515ce5d8?ixlib=rb-4.1.0&auto=format&fit=crop&w=300&q=80",
    rating: 4.8,
    year: 1960
  }
];

export const genres = [
  "All",
  "Fiction",
  "Non-fiction",
  "Science Fiction",
  "Mystery",
  "Fantasy",
  "Self-help",
  "Young Adult"
];
  