import  { Filter } from "lucide-react";

interface GenreSelectorProps {
  genres: string[];
  selectedGenre: string;
  onGenreChange: (genre: string) => void;
}

export default function GenreSelector({ 
  genres, 
  selectedGenre, 
  onGenreChange 
}: GenreSelectorProps) {
  return (
    <div className="my-6">
      <div className="flex items-center gap-2 mb-3">
        <Filter className="h-5 w-5 text-indigo-600" />
        <h2 className="text-lg font-semibold text-gray-800">Filter by Genre</h2>
      </div>
      <div className="flex flex-wrap gap-2">
        {genres.map((genre) => (
          <button
            key={genre}
            onClick={() => onGenreChange(genre)}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-colors
              ${selectedGenre === genre
                ? "bg-indigo-600 text-white"
                : "bg-gray-100 text-gray-700 hover:bg-gray-200"
              }`}
          >
            {genre}
          </button>
        ))}
      </div>
    </div>
  );
}
  