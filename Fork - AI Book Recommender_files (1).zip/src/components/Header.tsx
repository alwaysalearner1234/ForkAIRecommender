import  { Book } from "lucide-react";

export default function Header() {
  return (
    <header className="bg-gradient-to-r from-blue-600 to-indigo-700 py-6 shadow-md">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-center md:justify-start">
          <Book className="h-8 w-8 text-white mr-3" />
          <h1 className="text-2xl md:text-3xl font-bold text-white">
            AI Book Recommender
          </h1>
        </div>
        <p className="text-center md:text-left text-blue-100 mt-2">
          Discover your next favorite book with AI-powered recommendations
        </p>
      </div>
    </header>
  );
}
  